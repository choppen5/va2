rem
rem Drop Tables
rem
rem
rem Target DBMS: 'Oracle'
rem
 
 
rem
rem Drop Table          : sft_sub_elmnt
rem
DROP TABLE sft_sub_elmnt;
 
 
rem
rem Drop Table          : analysis_err
rem
DROP TABLE analysis_err;
 
 
rem
rem Drop Table          : com_srvr_vals
rem
DROP TABLE com_srvr_vals;
 
 
rem
rem Drop Table          : comp_errdef
rem
DROP TABLE comp_errdef;
 
 
rem
rem Drop Table          : sft_err_deff
rem
DROP TABLE sft_err_deff;
 
 
rem
rem Drop Table          : sft_elmnt_comp
rem
DROP TABLE sft_elmnt_comp;
 
 
rem
rem Drop Table          : sft_elmnt
rem
DROP TABLE sft_elmnt;
 
 
rem
rem Drop Table          : sft_product
rem
DROP TABLE sft_product;
 
 
rem
rem Drop Table          : stat_vals
rem
DROP TABLE stat_vals;
 
 
rem
rem Drop Table          : reaction
rem
DROP TABLE reaction;
 
 
rem
rem Drop Table          : com_admin
rem
DROP TABLE com_admin;
 
 
rem
rem Drop Table          : host_os_stats
rem
DROP TABLE host_os_stats;
 
 
rem
rem Drop Table          : errorexceptions
rem
DROP TABLE errorexceptions;
 
 
rem
rem Drop Table          : notification_rule
rem
DROP TABLE notification_rule;
 
 
rem
rem Drop Table          : administrators
rem
DROP TABLE administrators;
 
 
rem
rem Drop Table          : components
rem
DROP TABLE components;
 
 
rem
rem Drop Table          : processes
rem
DROP TABLE processes;
 
 
rem
rem Drop Table          : monitored_comps
rem
DROP TABLE monitored_comps;
 
 
rem
rem Drop Table          : server_task
rem
DROP TABLE server_task;
 
 
rem
rem Drop Table          : sft_error_defs
rem
DROP TABLE sft_error_defs;
 
 
rem
rem Drop Table          : sft_mng_sys
rem
DROP TABLE sft_mng_sys;
 
 
rem
rem Drop Table          : collector
rem
DROP TABLE collector;
 
 
rem
rem Drop Table          : reaction_grp
rem
DROP TABLE reaction_grp;
 
 
rem
rem Drop Table          : analysis_rule
rem
DROP TABLE analysis_rule;
 
 
rem
rem Drop Table          : system_msg
rem
DROP TABLE system_msg;
 
 
rem
rem Drop Table          : comunicationserver
rem
DROP TABLE comunicationserver;
 
 
rem
rem Drop Table          : schedule
rem
DROP TABLE schedule;
 
 
rem
rem Drop Table          : host
rem
DROP TABLE host;
 
 
rem
rem Drop Table          : errorevent
rem
DROP TABLE errorevent;
 
