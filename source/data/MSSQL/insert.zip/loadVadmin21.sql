 
sqlldr userid=coppenheimer/ control=errorevent.ctl log=errorevent.log
 
 
sqlldr userid=coppenheimer/ control=host.ctl log=host.log
 
 
sqlldr userid=coppenheimer/ control=schedule.ctl log=schedule.log
 
 
sqlldr userid=coppenheimer/ control=comunicationserver.ctl log=comunicationserver.log
 
 
sqlldr userid=coppenheimer/ control=system_msg.ctl log=system_msg.log
 
 
sqlldr userid=coppenheimer/ control=analysis_rule.ctl log=analysis_rule.log
 
 
sqlldr userid=coppenheimer/ control=reaction_grp.ctl log=reaction_grp.log
 
 
sqlldr userid=coppenheimer/ control=collector.ctl log=collector.log
 
 
sqlldr userid=coppenheimer/ control=sft_mng_sys.ctl log=sft_mng_sys.log
 
 
sqlldr userid=coppenheimer/ control=sft_error_defs.ctl log=sft_error_defs.log
 
 
sqlldr userid=coppenheimer/ control=server_task.ctl log=server_task.log
 
 
sqlldr userid=coppenheimer/ control=monitored_comps.ctl log=monitored_comps.log
 
 
sqlldr userid=coppenheimer/ control=processes.ctl log=processes.log
 
 
sqlldr userid=coppenheimer/ control=components.ctl log=components.log
 
 
sqlldr userid=coppenheimer/ control=administrators.ctl log=administrators.log
 
 
sqlldr userid=coppenheimer/ control=notification_rule.ctl log=notification_rule.log
 
 
sqlldr userid=coppenheimer/ control=errorexceptions.ctl log=errorexceptions.log
 
 
sqlldr userid=coppenheimer/ control=host_os_stats.ctl log=host_os_stats.log
 
 
sqlldr userid=coppenheimer/ control=com_admin.ctl log=com_admin.log
 
 
sqlldr userid=coppenheimer/ control=reaction.ctl log=reaction.log
 
 
sqlldr userid=coppenheimer/ control=stat_vals.ctl log=stat_vals.log
 
 
sqlldr userid=coppenheimer/ control=sft_product.ctl log=sft_product.log
 
 
sqlldr userid=coppenheimer/ control=sft_elmnt.ctl log=sft_elmnt.log
 
 
sqlldr userid=coppenheimer/ control=sft_elmnt_comp.ctl log=sft_elmnt_comp.log
 
 
sqlldr userid=coppenheimer/ control=sft_err_deff.ctl log=sft_err_deff.log
 
 
sqlldr userid=coppenheimer/ control=comp_errdef.ctl log=comp_errdef.log
 
 
sqlldr userid=coppenheimer/ control=com_srvr_vals.ctl log=com_srvr_vals.log
 
 
sqlldr userid=coppenheimer/ control=analysis_err.ctl log=analysis_err.log
 
 
sqlldr userid=coppenheimer/ control=sft_sub_elmnt.ctl log=sft_sub_elmnt.log
 
